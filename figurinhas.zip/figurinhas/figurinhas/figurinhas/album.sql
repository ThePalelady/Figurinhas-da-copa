
USE figurinhas;

DROP TABLE IF EXISTS figurinhas;
DROP TABLE IF EXISTS times;

CREATE TABLE times (
  timeId int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nome varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE figuras (
  id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  jogador varchar(100) NOT NULL,
  arquivoImagem varchar(100) NOT NULL,
  altura float(3,2) NOT NULL,
  peso int(3) NOT NULL,
  timeId int,
  FOREIGN KEY (timeId) REFERENCES times(timeId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO times (
  nome
) VALUES ('brasil'),
  ('alemanha'),
  ('argentina'),
  ('Noruega'),
  ('Inglaterra');


INSERT INTO figurinhas (timeId, jogador, arquivoImagem, altura, peso) VALUES
                (1, 'Neymar', 'neymar.jpg', 1.74, 70),
                (1, 'Alisson', 'alisson.jpg', 1.89, 80),
                (2, 'Kai', 'kai.jpg', 1.90, 83),
                (2, 'Thilo', 'thilo.jpg', 1.86, 76),
                (3, 'Messi', 'messi.jpg', 1.69, 67),
                (3, 'Joaquím', 'joaquim.jpg', 1.88, 77),
                (4, 'Mbappe', 'mbappe.jpg', 1.78, 73),
                (4, 'Benjamin', 'benjamin.jpg', 1.86, 81),
                (5, 'Daichi', 'daichi.jpg', 1.84, 72),
                (5, 'Shogo', 'shogo.jpg', 1.83, 75)