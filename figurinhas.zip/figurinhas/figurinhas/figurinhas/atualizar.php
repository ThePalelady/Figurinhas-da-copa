<?php

session_start();

require_once 'conexao.php';

if (isset($_POST['btn-editar'])) :
  $jogador = mysqli_escape_string($conexao, $_POST['jogador']);
  $altura = mysqli_escape_string($conexao, $_POST['Altura']);
  $peso = mysqli_escape_string($conexao, $_POST['peso']);
  $id = mysqli_escape_string($conexao, $_POST['id']);

  $sql = "UPDATE figurinhas set jogador = '$jogador', altura = '$altura', 
        peso = '$peso' WHERE id = '$id'";

  if (mysqli_query($conexao, $sql)) :
    $_SESSION['mensagem'] = "Atualizado com sucesso!";
    header('Location: index.php');
  else :
    $_SESSION['mensagem'] = "Erro ao atualizar";
    header('Location: index.php');
  endif;

endif;
