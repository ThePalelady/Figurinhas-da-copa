<?php
include_once 'conexao.php';
include_once 'header.php';

if (isset($_GET['id'])) :
  $id = mysqli_escape_string($conexao, $_GET['id']);
  $sql = "SELECT * FROM figurinhas WHERE id = '$id'";
  $res = mysqli_query($conexao, $sql);
  $dados = mysqli_fetch_array($res);
endif;
?>

<div class="row">
  <div class="col s12 m6 push-m3">
    <h3 class="light">Editar Jogador</h3>
    <form action="atualizar.php" method="POST">
      <input type="hidden" name="id" value="<?php echo $dados['id']; ?>">
      <div class="input-field col s12">
        <input type="text" name="jogador" id="jogador" value="<?php echo $dados['jogador']; ?>">
        <label for="nome">Jogador</label>
      </div>
      <div class="input-field col s12">
        <input type="text" name="peso" id="peso" value="<?php echo $dados['peso']; ?>">
        <label for="peso">Peso</label>
      </div>
      <div class="input-field col s12">
        <input type="text" name="Altura" id="Altura" value="<?php echo $dados['altura']; ?>">
        <label for="Altura">Altura</label>
      </div>
      <button type="submit" name="btn-editar" class="btn">Atualizar</button>
      <a href="index.php" class="btn green">Jogadores</a>
    </form>
  </div>
</div>

<?php include_once 'footer.php' ?>