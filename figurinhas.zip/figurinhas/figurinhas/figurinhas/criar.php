<?php
session_start();

require_once 'conexao.php';

if (isset($_POST['btn-cadastrar'])) :
  $jogador = mysqli_escape_string($conexao, $_POST['jogador']);
  $altura =  mysqli_escape_string($conexao, $_POST['altura']);
  $peso = mysqli_escape_string($conexao, $_POST['peso']);
  $timeId = mysqli_escape_string($conexao, $_POST['timeId']);

  $imagem = $_FILES["arquivo"];
  $nomeArquivo = strtolower($imagem['name']);
  move_uploaded_file($imagem['tmp_name'], "imagens/" . $nomeArquivo);

  $sql = "INSERT INTO figurinhas (jogador, arquivoImagem, altura, peso, timeId) VALUES ('$jogador', '$nomeArquivo','$altura', '$peso', '$timeId')";

  if (mysqli_query($conexao, $sql)) :
    $_SESSION['mensagem'] = "Jogador criado com sucesso!";
  else :
    $_SESSION['mensagem'] = "Erro ao criar um jogador";
  endif;

  header('Location: index.php');

endif;
