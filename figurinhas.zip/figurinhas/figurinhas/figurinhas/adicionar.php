<?php include_once 'header.php'; ?>


<div class="row">
  <div class="col s12 m6 push-m3">
    <h3 class="light">Novo Jogador</h3>
    <form action="criar.php" method="POST" enctype="multipart/form-data">
      <div class="input-field col s12">
        <input type="text" name="jogador" id="jogador">
        <label for="jogador">Jogador</label>
      </div>
      <div class="input-field col s12">
        <input type="number" max="90" min="50" name="peso" id="peso">
        <label for="peso">Peso</label>
      </div>
      <div class="input-field col s12">
        <input type="number" step="0.1" max="2.5" name="altura" id="altura">
        <label for="altura">Altura</label>
      </div>
      <div class="input-field col s12">
        <input type="file" name="arquivo" id="arquivo">
      </div>
      <div>
        <p>
          <label>
            <input name="timeId" type="radio" value="1" checked />
            <span>Brasil</span>
          </label>
        </p>
        <p>
          <label>
            <input name="timeId" value="2"type="radio" />
            <span>Alemanha</span>
          </label>
        </p>
        <p>
          <label>
            <input class="with-gap" value="3"name="timeId" type="radio" />
            <span>Argentina</span>
          </label>
        </p>
        <p>
          <label>
            <input class="with-gap" value="4" name="timeId" type="radio" />
            <span>Noruega</span>
          </label>
        </p>
        <p>
          <label>
            <input class="with-gap" value="5" name="timeId" type="radio" />
            <span>Inglaterra</span>
          </label>
        </p>

      </div>
      <button type="submit" name="btn-cadastrar" class="btn">Cadastrar</button>
      <a href="jogadores.php" class="btn green">Jogadores</a>
    </form>
  </div>
</div>

<?php include_once 'footer.php' ?>