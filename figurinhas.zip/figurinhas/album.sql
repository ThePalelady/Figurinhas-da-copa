CREATE DATABASE IF NOT EXISTS figurinhas;
USE figurinhas;

DROP TABLE IF EXISTS figurinhas;
DROP TABLE IF EXISTS times;

CREATE TABLE times (
  timeId int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nome varchar(100) NOT NULL,
  timeImagem varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE figurinhas (
  id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  jogador varchar(100) NOT NULL,
  figurinhaImagem varchar(100) NOT NULL,
  altura float(3,2) NOT NULL,
  peso int(3) NOT NULL,
  ano int(4),
  timeId int,
  FOREIGN KEY (timeId) REFERENCES times(timeId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO times (
  timeImagem,
  nome
) VALUES ('Brasil.png','brasil'),
  ('Alemanha.png','alemanha'),
  ('Argentina.png','argentina'),
  ('Noruega.png','Noruega'),
  ('Inglaterra.png','Inglaterra');


INSERT INTO figurinhas (timeId, jogador, figurinhaImagem, altura, peso, ano) VALUES
  (1, 'Neymar', 'Neymar.png', 1.74, 70, 2021),
  (1, 'Gabriel Jesuis', 'GabrielJesuis.png', 1.89, 80, 2021),
  (2, 'kai havertz', 'kaihavertzAlemanha.png', 1.90, 83, 2021),
  (2, 'Manuel Neuer', 'ManuelNeuerAlemanha.png', 1.86, 76, 2021),
  (3, 'Lionel Messi', 'MessiArgentina.png', 1.69, 67, 2021),
  (3, 'Maradona', 'MaradonaArgentina.png', 1.88, 77, 2021),
  (4, 'Erling Haaland', 'ErlingHaalandNoruega.png', 1.78, 73, 2021),
  (4, 'Sander Berge', 'SanderBergeNoruega.png', 1.86, 81, 2021),
  (5, 'Harry Kane', 'HarryKaneInglaterra.png', 1.84, 72, 2021),
  (5, 'David Beckham', 'DavidBeckhamIngles.png', 1.83, 75, 2021)