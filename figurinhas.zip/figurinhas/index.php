<?php
include_once 'header.php';
include_once 'conexao.php';
include_once 'mensagem.php';
?>

<div class="row">
  <div class="col s12 m6 push-m3">
    <h3 class="light">Figurinhas</h3>
    <table class="striped">
      <thead>
        <tr>
          <th>Foto:</th>
          <th>Jogador:</th>
          <th>Altura:</th>
          <th>Peso:</th>
          <th>Ano:</th>
          <th>Time:</th>
        </tr>
      </thead>

      <tbody>
        <?php
        $sql = "SELECT * FROM figurinhas INNER JOIN times ON figurinhas.timeId = times.timeId;";
        $res = mysqli_query($conexao, $sql);
        while ($dados = mysqli_fetch_array($res)):
        ?>
          <tr>
            <td><img style="max-width: 40px;" src="imagens/<?php echo $dados['figurinhaImagem']; ?>"/></td>
            <td><?php echo $dados['jogador']; ?></td>
            <td><?php echo $dados['altura']; ?></td>
            <td><?php echo $dados['peso']; ?></td>
            <td><?php echo $dados['ano']; ?></td>
            <td><img style="max-width: 40px;" src="imagens/<?php echo $dados['timeImagem']; ?>"/></td>
            <td><a href="editar.php?id=<?php echo $dados['id']; ?>" class="btn-floating orange"><i class="material-icons">edit</i></a></td>
            <td><a href="#modal<?php echo $dados['id']; ?>" class="btn-floating red modal-trigger"><i class="material-icons">delete</i></a></td>
            <div id="modal<?php echo $dados['id']; ?>" class="modal">
              <div class="modal-content">
                <p>Tem certeza?</p>
              </div>
              <div class="modal-footer">
                <form action="deletar.php" method="POST">
                  <input type="hidden" name="id" value="<?php echo $dados['id']; ?>">
                  <button type="submit" name="btn-deletar" class="btn ted">Sim, tenho certeza</button>
                  <a href="#!" class="modal-close waves-effect waves-green btn-flat">Cancelar</a>
                </form>
              </div>
            </div>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <br>
    <a href="adicionar.php" class="btn">Adicionar Figurinhas</a>
  </div>
</div>

<?php include_once 'footer.php' ?>