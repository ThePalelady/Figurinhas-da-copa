<?php
    $conexao = mysqli_connect("localhost", "root", "", "figurinhas");
    mysqli_set_charset($conexao, "utf8");

    if(mysqli_connect_error()):
      echo "Falha na conexão ";
    endif;
