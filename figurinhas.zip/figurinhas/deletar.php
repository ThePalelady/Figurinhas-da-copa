<?php

session_start();

require_once 'conexao.php';

if (isset($_POST['btn-deletar'])):
  $id = mysqli_escape_string($conexao, $_POST['id']);
  $sql = "DELETE FROM figurinhas WHERE id = '$id'";

  if (mysqli_query($conexao, $sql)):
    $_SESSION['mensagem'] = "Deletado com sucesso!";
    header('Location: index.php');
  else:
    $_SESSION['mensagem'] = "Erro ao deletar";
    header('Location: index.php');
  endif;

endif;
